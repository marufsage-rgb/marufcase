const G=window.GUARDIAN;const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
async function api(path,opts={}){opts.headers=Object.assign({'X-Requested-With':'Guardian'},opts.headers||{});let r=await fetch(G.base+'/api/'+path,opts);let j=await r.json().catch(()=>({ok:false,error:'Invalid server response'}));if(!r.ok||j.ok===false)throw new Error(j.error||'Request failed');return j;}
function formData(f){let d=new FormData(f);d.append('csrf',G.csrf);return d;}
function esc(x){return String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
function show(id){$$('.view').forEach(x=>x.classList.remove('active'));$('#'+id).classList.add('active');load(id);}
$$('aside button[data-view]').forEach(b=>b.onclick=()=>show(b.dataset.view));
async function load(view){try{
 if(view==='dashboard'){let s=await api('stats.php');$('#statCases').textContent=s.cases;$('#statDocs').textContent=s.documents;$('#statFindings').textContent=s.findings;$('#statAlerts').textContent=s.alerts;}
 if(view==='cases'){let j=await api('cases.php');$('#caseList').innerHTML=j.rows.map(x=>`<div class=row><b>${esc(x.case_no)}</b> — ${esc(x.title)} <span>${esc(x.risk)}</span></div>`).join('');fillCases(j.rows);}
 if(view==='evidence'){let j=await api('documents.php');$('#docList').innerHTML=j.rows.map(x=>`<div class=row><b>${esc(x.original_name)}</b><br><small>${esc(x.evidence_status)} · SHA256 ${esc(x.sha256)}</small></div>`).join('');}
 if(view==='law'){let j=await api('sources.php');$('#lawList').innerHTML=j.rows.map(x=>`<div class=row><b>${esc(x.title)}</b><br>${esc(x.citation||'')} ${x.url?`<a target=_blank href="${esc(x.url)}">Official source</a>`:''}</div>`).join('');}
 if(view==='alerts'){let j=await api('alerts.php');$('#alertList').innerHTML=j.rows.map(x=>`<div class=row><b>${esc(x.title)}</b> · ${esc(x.alert_date)}<br>${esc(x.message||'')}</div>`).join('');}
 if(view==='audit'){let j=await api('audit.php');$('#auditList').innerHTML=j.rows.map(x=>`<div class=row><b>${esc(x.action)}</b> · ${esc(x.created_at)} · ${esc(x.details||'')}</div>`).join('');}
 }catch(e){alert(e.message)}}
function fillCases(rows){['uploadCase','researchCase','alertCase'].forEach(id=>{let s=$('#'+id);s.innerHTML=rows.map(x=>`<option value="${x.id}">${esc(x.case_no)} — ${esc(x.title)}</option>`).join('');});}
$('#caseForm').onsubmit=async e=>{e.preventDefault();try{await api('cases.php',{method:'POST',body:formData(e.target)});e.target.reset();show('cases')}catch(x){alert(x.message)}};
$('#uploadForm').onsubmit=async e=>{e.preventDefault();try{await api('documents.php',{method:'POST',body:formData(e.target)});e.target.reset();show('evidence')}catch(x){alert(x.message)}};
$('#lawForm').onsubmit=async e=>{e.preventDefault();try{await api('sources.php',{method:'POST',body:formData(e.target)});e.target.reset();show('law')}catch(x){alert(x.message)}};
$('#alertForm').onsubmit=async e=>{e.preventDefault();try{await api('alerts.php',{method:'POST',body:formData(e.target)});e.target.reset();show('alerts')}catch(x){alert(x.message)}};
$('#runAI').onclick=async()=>{let q=$('#question').value.trim();if(!q)return alert('Enter a question');$('#aiOut').textContent='Running…';try{let j=await api('research.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({csrf:G.csrf,case_id:$('#researchCase').value,agent:$('#agent').value,question:q})});$('#aiOut').textContent=j.answer;}catch(e){$('#aiOut').textContent=e.message}};
load('dashboard');