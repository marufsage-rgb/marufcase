<?php
declare(strict_types=1);
function envv(string $k,string $d=''):string { $v=getenv($k); return ($v===false||$v==='')?$d:$v; }
// Copy to config.php or use server environment variables.
return [
 'app_name'=>'Oman AI Case Guardian — MarufEdge FINAL',
 'timezone'=>envv('GUARDIAN_TIMEZONE','Asia/Muscat'),
 'base_url'=>rtrim(envv('GUARDIAN_BASE_URL',''),'/'),
 'db'=>[
   'host'=>envv('GUARDIAN_DB_HOST','127.0.0.1'),
   'name'=>envv('GUARDIAN_DB_NAME','oman_case_guardian'),
   'user'=>envv('GUARDIAN_DB_USER',''),
   'pass'=>envv('GUARDIAN_DB_PASS',''),
   'charset'=>'utf8mb4'
 ],
 'security'=>[
   'session_name'=>envv('GUARDIAN_SESSION','marufedge_guardian'),
   'encryption_key'=>envv('GUARDIAN_ENCRYPTION_KEY','CHANGE_ME'),
   'max_login_attempts'=>8
 ],
 'uploads'=>[
   'max_mb'=>(int)envv('GUARDIAN_MAX_UPLOAD_MB','50'),
   'allowed'=>['pdf','doc','docx','xls','xlsx','csv','txt','jpg','jpeg','png','webp','zip','eml','msg']
 ],
 'ai'=>[
   'provider'=>envv('GUARDIAN_AI_PROVIDER','gemini'),
   'model'=>envv('GUARDIAN_AI_MODEL','gemini-2.5-flash'),
   'api_key'=>envv('GUARDIAN_AI_API_KEY','')
 ],
 'firebase'=>[
   'api_key'=>envv('FIREBASE_API_KEY',''),
   'auth_domain'=>envv('FIREBASE_AUTH_DOMAIN',''),
   'project_id'=>envv('FIREBASE_PROJECT_ID',''),
   'app_id'=>envv('FIREBASE_APP_ID','')
 ],
 'allowed_signup_emails'=>[
   'habiburmaruf@gmail.com','marufsage@gmail.com','lion.maruf@gmail.com'
 ]
];
