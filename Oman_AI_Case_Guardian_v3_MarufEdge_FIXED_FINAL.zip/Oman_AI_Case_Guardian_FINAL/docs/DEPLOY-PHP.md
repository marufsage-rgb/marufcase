# PHP deployment

### cPanel / Infinity-style PHP hosting
- PHP 8.2+
- MySQL/MariaDB
- PDO MySQL
- OpenSSL
- cURL
- fileinfo
- HTTPS
- writable `storage/uploads`

Import `database/schema.sql`, configure DB credentials, run `auth/setup.php`, then delete setup.php.

### Cron
If cron is available:
`*/30 * * * * /usr/bin/php /home/USER/public_html/cron/alerts.php`

If the host does not provide cron, alerts remain visible when the dashboard is opened.

### Troubleshooting
- 500 error: check PHP version/extensions and DB credentials.
- Database error: verify DB name/user/password and privileges.
- Upload error: check PHP upload_max_filesize/post_max_size and storage permissions.
- Login error: make sure setup created an account from the approved email list.
