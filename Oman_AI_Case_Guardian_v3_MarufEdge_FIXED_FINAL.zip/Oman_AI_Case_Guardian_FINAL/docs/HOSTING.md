# Hosting matrix

## Best choice for this package
**PHP + MySQL host**: runs the complete application directly.

## Firebase
Use `firebase/public` for the static portal. Firebase Hosting can host static content and can be paired with Cloud Functions/Cloud Run for dynamic APIs. Do not expect `index.php` to execute on Firebase Hosting.

## Netlify
Use `netlify/` for the static/serverless adapter. The complete PHP/MySQL backend is not the same runtime as a Netlify Function.

## Vercel
Use `vercel/` for the static/serverless adapter. Keep the PHP/MySQL backend on a PHP host or migrate the entire backend to a supported serverless/container architecture.

## Free hosting warning
Free hosts may disable cron, restrict uploads, impose low PHP limits, or suspend inactive sites. Always test uploads, DB access, HTTPS, and backups before storing real case evidence.
