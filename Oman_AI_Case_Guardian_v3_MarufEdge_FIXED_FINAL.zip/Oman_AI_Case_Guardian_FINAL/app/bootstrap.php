<?php
declare(strict_types=1);
$config=require __DIR__.'/../config/config.php';
date_default_timezone_set($config['timezone']);
session_name($config['security']['session_name']);
session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','samesite'=>'Lax']);
session_start();
header_remove('X-Powered-By');
function cfg():array{global $config;return $config;}
function base_url(string $p=''):string{
 $b=cfg()['base_url']; if($b!=='') return $b.'/'.ltrim($p,'/');
 $script=str_replace('\\','/',$_SERVER['SCRIPT_NAME']??'');
 $root=preg_replace('~/(auth|api)(/.*)?$~','',$script); $root=rtrim((string)$root,'/');
 return $root.'/'.ltrim($p,'/');
}
function e(?string $v):string{return htmlspecialchars($v??'',ENT_QUOTES,'UTF-8');}
function db():PDO{
 static $pdo=null; if($pdo instanceof PDO)return $pdo;
 $c=cfg()['db'];
 if($c['user']===''||$c['name']==='') throw new RuntimeException('Database is not configured. Edit config/config.php or environment variables.');
 $pdo=new PDO("mysql:host={$c['host']};dbname={$c['name']};charset={$c['charset']}",$c['user'],$c['pass'],[
   PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false
 ]);
 return $pdo;
}
function json_body():array{return json_decode(file_get_contents('php://input'),true)?:[];}
function json_out(array $x,int $code=200):never{http_response_code($code);header('Content-Type: application/json; charset=utf-8');echo json_encode($x,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function csrf():string{if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];}
function check_csrf():void{if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??''))die('Invalid CSRF token');}
function user():?array{return $_SESSION['user']??null;}
function require_auth():void{if(!user()){header('Location: '.base_url('auth/login.php'));exit;}}
function require_owner():void{require_auth();if(!in_array(user()['role'],['owner','admin'],true)){http_response_code(403);exit('Forbidden');}}
function audit(string $action,string $object='',?int $id=null,array $details=[]):void{
 try{ $u=user(); $s=db()->prepare('INSERT INTO audit_log(user_id,action,object_type,object_id,ip_hash,details) VALUES(?,?,?,?,?,?)');
 $s->execute([$u['id']??null,$action,$object,$id,hash('sha256',$_SERVER['REMOTE_ADDR']??''),json_encode($details,JSON_UNESCAPED_UNICODE)]);}catch(Throwable $e){}
}
function allowed_email(string $email):bool{return in_array(strtolower(trim($email)),cfg()['allowed_signup_emails'],true);}
function enc(string $plain):string{
 $key=hash('sha256',cfg()['security']['encryption_key'],true);$iv=random_bytes(12);$tag='';
 $cipher=openssl_encrypt($plain,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);return base64_encode($iv.$tag.$cipher);
}
function dec(?string $v):string{
 if(!$v)return ''; $r=base64_decode($v,true);if($r===false||strlen($r)<29)return '';
 return (string)openssl_decrypt(substr($r,28),'aes-256-gcm',hash('sha256',cfg()['security']['encryption_key'],true),OPENSSL_RAW_DATA,substr($r,0,12),substr($r,12,16));
}
