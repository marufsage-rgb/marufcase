<?php require __DIR__.'/../app/bootstrap.php';
$count=(int)db()->query("SELECT COUNT(*) FROM users")->fetchColumn();
if($count>0) exit('Setup already completed. Remove/rename auth/setup.php for security.');
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){check_csrf();$name=trim($_POST['name']??'');$email=strtolower(trim($_POST['email']??''));$pw=$_POST['password']??'';
 if(!allowed_email($email))$msg='This email is not on the approved signup list.';
 elseif(strlen($pw)<12)$msg='Password must be at least 12 characters.';
 elseif($name==='')$msg='Name is required.';
 else{db()->prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'owner')")->execute([$name,$email,password_hash($pw,PASSWORD_DEFAULT)]);$msg='Owner created. Delete auth/setup.php, then login.';}}
?><!doctype html><html><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><link rel=stylesheet href="<?=e(base_url('assets/app.css'))?>"><title>Guardian Setup</title></head><body class=auth><form method=post class=authbox><h1>⚖️ First-time setup</h1><p>Approved accounts only.</p><input type=hidden name=csrf value="<?=e(csrf())?>"><input name=name required placeholder="Full name"><input name=email type=email required placeholder="Approved email"><input name=password type=password minlength=12 required placeholder="Password (12+ characters)"><button class=primary>Create Owner</button><p class=msg><?=e($msg)?></p><small>Approved: habiburmaruf@gmail.com · marufsage@gmail.com · lion.maruf@gmail.com</small></form></body></html>